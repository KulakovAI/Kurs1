﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using ElectronicDiary.Classes;
using ElectronicDiary.Pages;

namespace ElectronicDiary.Pages
{
    /// <summary>
    /// Логика взаимодействия для PageTeacher.xaml
    /// </summary>
    public partial class PageTeacher : Page
    {
        public PageTeacher()
        {
            InitializeComponent();
            lstTeacher.ItemsSource = ElectronicDiaryEntities.GetContext().Teacher.ToList();
        }

        //private void SearchTeacher_Name_TextChanged(object sender, TextChangedEventArgs e)
        //{
        //    if (DtgTeacher.ItemsSource != null)
        //    {
        //        DtgTeacher.ItemsSource = ElectronicDiaryEntities.GetContext().Teacher.Where(x => x.FIO.ToLower().Contains(SearchTeacher_Name.Text.ToLower())).ToList();
        //    }
        //    if (SearchTeacher_Name.Text.Count() == 0) DtgTeacher.ItemsSource = ElectronicDiaryEntities.GetContext().Teacher.ToList();
        //}

        private void MenuSortTeacher_Click(object sender, RoutedEventArgs e)
        {
            lstTeacher.ItemsSource = ElectronicDiaryEntities.GetContext().Teacher.OrderBy(x => x.FIO).ToList();
        }

        private void MenuSortTeacher2_Click(object sender, RoutedEventArgs e)
        {
            lstTeacher.ItemsSource = ElectronicDiaryEntities.GetContext().Teacher.OrderByDescending(x => x.FIO).ToList();
        }

        private void MenuSortClear_Click(object sender, RoutedEventArgs e)
        {
            lstTeacher.ItemsSource = ElectronicDiaryEntities.GetContext().Teacher.ToList();
        }

        private void MenuAddTeacher_Click(object sender, RoutedEventArgs e)
        {
            Classes.ClassFrame.frmObj.Navigate(new PageAddTeacher(null));
        }

        private void MenuEditTeacher_Click(object sender, RoutedEventArgs e)
        {
            Classes.ClassFrame.frmObj.Navigate(new PageAddTeacher((Teacher)lstTeacher.SelectedItem));
        }

        private void MenuSortTeacherAge_Click(object sender, RoutedEventArgs e)
        {
            lstTeacher.ItemsSource = ElectronicDiaryEntities.GetContext().Teacher.OrderBy(x => x.Age).ToList();
        }

        private void MenuSortTeacherAge2_Click(object sender, RoutedEventArgs e)
        {
            lstTeacher.ItemsSource = ElectronicDiaryEntities.GetContext().Teacher.OrderByDescending(x => x.Age).ToList();
        }

        private void MenuSortClear2_Click(object sender, RoutedEventArgs e)
        {
            lstTeacher.ItemsSource = ElectronicDiaryEntities.GetContext().Teacher.ToList();
        }

        private void TeacherDel_Click(object sender, RoutedEventArgs e)
        {
            var TeacherForRemoving = lstTeacher.SelectedItems.Cast<Teacher>().ToList();
            if (MessageBox.Show($"Вы точно хотите удалить следующие {TeacherForRemoving.Count()} записи?", "Внимание", MessageBoxButton.YesNo, MessageBoxImage.Question) == MessageBoxResult.Yes)
            {
                try
                {
                    ElectronicDiaryEntities.GetContext().Teacher.RemoveRange(TeacherForRemoving);
                    ElectronicDiaryEntities.GetContext().SaveChanges();
                    MessageBox.Show("Данные удалены!");
                    lstTeacher.ItemsSource = ElectronicDiaryEntities.GetContext().Teacher.ToList();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message.ToString());
                }
            }
        }

        private void SearchTeacher_Name_TextChanged(object sender, TextChangedEventArgs e)
        {
            if (lstTeacher.ItemsSource != null)
            {
                lstTeacher.ItemsSource = ElectronicDiaryEntities.GetContext().Teacher.Where(x => x.FIO.ToLower().Contains(SearchTeacher_Name.Text.ToLower())).ToList();
            }
            if (SearchTeacher_Name.Text.Count() == 0) lstTeacher.ItemsSource = ElectronicDiaryEntities.GetContext().Teacher.ToList();
        }
    }
}



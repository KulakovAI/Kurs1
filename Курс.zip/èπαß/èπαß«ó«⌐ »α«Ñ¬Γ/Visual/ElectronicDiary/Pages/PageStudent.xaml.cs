﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using ElectronicDiary.Classes;
using ElectronicDiary.Pages;

namespace ElectronicDiary.Pages
{
    /// <summary>
    /// Логика взаимодействия для PageStudent.xaml
    /// </summary>
    public partial class PageStudent : Page
    {
        public PageStudent()
        {
            InitializeComponent();
            DtgStudent.ItemsSource = ElectronicDiaryEntities.GetContext().Student.ToList();
        }
        private void SearchStudent_Name_TextChanged(object sender, TextChangedEventArgs e)
        {
            if (DtgStudent.ItemsSource != null)
            {
                DtgStudent.ItemsSource = ElectronicDiaryEntities.GetContext().Student.Where(x => x.FIO.ToLower().Contains(SearchStudent_Name.Text.ToLower())).ToList();
            }
            if (SearchStudent_Name.Text.Count() == 0) DtgStudent.ItemsSource = ElectronicDiaryEntities.GetContext().Student.ToList();
        }

        private void MenuAddStudent_Click(object sender, RoutedEventArgs e)
        {
            Classes.ClassFrame.frmObj.Navigate(new PageAddStudent(null));
        }

        private void MenuEditStudent_Click(object sender, RoutedEventArgs e)
        {
            Classes.ClassFrame.frmObj.Navigate(new PageAddStudent((Student)DtgStudent.SelectedItem));
        }

        private void MenuSortStudent_Click(object sender, RoutedEventArgs e)
        {
            DtgStudent.ItemsSource = ElectronicDiaryEntities.GetContext().Student.OrderBy(x => x.FIO).ToList();
        }

        private void MenuSortStudent2_Click(object sender, RoutedEventArgs e)
        {
            DtgStudent.ItemsSource = ElectronicDiaryEntities.GetContext().Student.OrderByDescending(x => x.FIO).ToList();
        }

        private void MenuSortClear_Click(object sender, RoutedEventArgs e)
        {
            DtgStudent.ItemsSource = ElectronicDiaryEntities.GetContext().Student.ToList();
        }

        private void MenuDelStudent_Click(object sender, RoutedEventArgs e)
        {
            var StudentForRemoving = DtgStudent.SelectedItems.Cast<Student>().ToList();
            if (MessageBox.Show($"Вы точно хотите удалить следующие {StudentForRemoving.Count()} записи?", "Внимание", MessageBoxButton.YesNo, MessageBoxImage.Question) == MessageBoxResult.Yes)
            {
                try
                {
                    ElectronicDiaryEntities.GetContext().Student.RemoveRange(StudentForRemoving);
                    ElectronicDiaryEntities.GetContext().SaveChanges();
                    MessageBox.Show("Данные удалены!");
                    DtgStudent.ItemsSource = ElectronicDiaryEntities.GetContext().Student.ToList();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message.ToString());
                }
            }
        }

        private void MenuSortStudentAge_Click(object sender, RoutedEventArgs e)
        {
            DtgStudent.ItemsSource = ElectronicDiaryEntities.GetContext().Student.OrderBy(x => x.Age).ToList();
        }

        private void MenuSortStudentAge2_Click(object sender, RoutedEventArgs e)
        {
            DtgStudent.ItemsSource = ElectronicDiaryEntities.GetContext().Student.OrderByDescending(x => x.Age).ToList();
        }

        private void MenuSortClear2_Click(object sender, RoutedEventArgs e)
        {
            DtgStudent.ItemsSource = ElectronicDiaryEntities.GetContext().Student.ToList();
        }

        private void SearchStudent_Group_TextChanged(object sender, TextChangedEventArgs e)
        {
            if (DtgStudent.ItemsSource != null)
            {
                DtgStudent.ItemsSource = ElectronicDiaryEntities.GetContext().Student.Where(x => x.Group.TitleGroup.ToLower().Contains(SearchStudent_Group.Text.ToLower())).ToList();
            }
            if (SearchStudent_Group.Text.Count() == 0) DtgStudent.ItemsSource = ElectronicDiaryEntities.GetContext().Student.ToList();
        }
    }
}
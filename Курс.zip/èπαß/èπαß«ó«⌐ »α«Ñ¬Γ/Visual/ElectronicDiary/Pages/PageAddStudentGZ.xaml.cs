﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using ElectronicDiary.Classes;

namespace ElectronicDiary.Pages
{
    /// <summary>
    /// Логика взаимодействия для PageAddStudentGZ.xaml
    /// </summary>
    public partial class PageAddStudentGZ : Page
    {
        public PageAddStudentGZ()
        {
            InitializeComponent();
            lstvD.ItemsSource = ElectronicDiaryEntities.GetContext().Student.ToList();
        }

        private void txbSearchDeposit_TextChanged(object sender, TextChangedEventArgs e)
        {

        }

        private void MenuSortDeposits1_Click(object sender, RoutedEventArgs e)
        {

        }

        private void MenuSortDeposits2_Click(object sender, RoutedEventArgs e)
        {

        }

        private void MenuItem_Click(object sender, RoutedEventArgs e)
        {

        }

        private void MenuDelDeposit_Click(object sender, RoutedEventArgs e)
        {

        }
    }
}
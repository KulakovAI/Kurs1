﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using ElectronicDiary.Classes;

namespace ElectronicDiary.Pages
{
    /// <summary>
    /// Логика взаимодействия для PageAddStudent.xaml
    /// </summary>
    public partial class PageAddStudent : Page
    {
        private Student _currentStudent = new Student();
        public PageAddStudent(Student selectedStudent)
        {
            InitializeComponent();
            if (selectedStudent != null)
            {
                _currentStudent = selectedStudent;
                TitleCitizen.Text = "Изменение собственника";
                BtnAddStudent.Content = "Изменить";
            }
            DataContext = _currentStudent;
            CMBGroups.ItemsSource = ElectronicDiaryEntities.GetContext().Group.ToList();
            CMBGroups.SelectedValuePath = "idGroup";
            CMBGroups.DisplayMemberPath = "TitleGroup";
        }

        private void BtnAddStudent_Click(object sender, RoutedEventArgs e)
        {
            StringBuilder error = new StringBuilder();
            if (string.IsNullOrWhiteSpace(_currentStudent.FIO)) error.AppendLine("Укажите ФИО");
            if (string.IsNullOrWhiteSpace(Convert.ToString(_currentStudent.Age))) error.AppendLine("Укажите возраст");
            if (string.IsNullOrWhiteSpace(Convert.ToString(_currentStudent.Groups))) error.AppendLine("Укажите группу ");
            if (error.Length > 0)
            {
                MessageBox.Show(error.ToString());
                return;
            }
            if (_currentStudent.idStudent == 0)
            {
                ElectronicDiaryEntities.GetContext().Student.Add(_currentStudent);
                try
                {
                    ElectronicDiaryEntities.GetContext().SaveChanges();
                    Classes.ClassFrame.frmObj.Navigate(new PageStudent());
                    MessageBox.Show("Новый студент успешно добавлен!");
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message.ToString());
                }
            }
            else
            {
                try
                {
                    ElectronicDiaryEntities.GetContext().SaveChanges();
                    Classes.ClassFrame.frmObj.Navigate(new PageStudent());
                    MessageBox.Show("студент успешно изменён!");
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message.ToString());
                }
            }
        }

        private void BtnCancelStudent_Click(object sender, RoutedEventArgs e)
        {
            Classes.ClassFrame.frmObj.Navigate(new PageStudent());
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using ElectronicDiary.Classes;
using Microsoft.Win32;

namespace ElectronicDiary.Pages
{
    /// <summary>
    /// Логика взаимодействия для PageAddTeacher.xaml
    /// </summary>
    public partial class PageAddTeacher : Page
    {
        private Teacher _currentTeacher = new Teacher();
        string imgLoc = "пусто";
        public PageAddTeacher(Teacher selectedTeacher)
        {
            InitializeComponent();
            if (selectedTeacher != null)
            {
                _currentTeacher = selectedTeacher;
                TitletxtTeacher.Text = "Редактирование учителя";
                BtnAddTeacher.Content = "Изменить";
            }
            // Создаём контекст
            DataContext = _currentTeacher;
        }

        private void BtnAddTeacher_Click(object sender, RoutedEventArgs e)
        {
            StringBuilder error = new StringBuilder();

            if (string.IsNullOrWhiteSpace(_currentTeacher.FIO)) error.AppendLine("Укажите ФИО");
            if (string.IsNullOrWhiteSpace(Convert.ToString(_currentTeacher.Age))) error.AppendLine("Укажите возрась");
            if (string.IsNullOrWhiteSpace(_currentTeacher.Telephone)) error.AppendLine("Укажите телефон");
            if (error.Length > 0)
            {
                MessageBox.Show(error.ToString());
                return;
            }
            if (_currentTeacher.idTeacher == 0)
            {
                ElectronicDiaryEntities.GetContext().Teacher.Add(_currentTeacher);
                try
                {
                    ElectronicDiaryEntities.GetContext().SaveChanges();
                    Classes.ClassFrame.frmObj.Navigate(new PageTeacher());
                    MessageBox.Show("Новый учитель успешно добавлен!");
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message.ToString());
                }
            }
            else
            {
                try
                {
                    if (imgLoc != null && imgLoc != "пусто")
                    {
                        byte[] img = null;
                        FileStream fs = new FileStream(imgLoc, FileMode.Open, FileAccess.Read);
                        BinaryReader br = new BinaryReader(fs);
                        img = br.ReadBytes((int)fs.Length);
                        _currentTeacher.PhotoT = img;
                    }

                    if (imgLoc == "пусто") _currentTeacher.PhotoT = null;

                    ElectronicDiaryEntities.GetContext().SaveChanges();
                    Classes.ClassFrame.frmObj.Navigate(new PageTeacher());
                    MessageBox.Show("Учитель успешно изменён!");
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message.ToString());
                }
            }
        }

        private void BtnCancelTeacher_Click(object sender, RoutedEventArgs e)
        {
            Classes.ClassFrame.frmObj.Navigate(new PageTeacher());
        }

        private void ImageLoad_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                OpenFileDialog dlg = new OpenFileDialog
                {
                    Filter = "JPG Files (*.jpg)|*.jpg|PNG Files (*.png)|*.png|GIF Files (*.gif)|*.gif|All Files (*.*)|*.*",
                    Title = "Выберите фото/изображение учителя"
                };
                if (dlg.ShowDialog() == true)
                {
                    imgLoc = dlg.FileName.ToString();
                    imageT.Source = new BitmapImage(new Uri(imgLoc));
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void ImageDel_Click(object sender, RoutedEventArgs e)
        {
            imageT.Source = (ImageSource)imageT.FindResource("UnknownT");
            imgLoc = "пусто";
        }
    }
}
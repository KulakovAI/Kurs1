﻿using ElectronicDiary.Classes;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using ElectronicDiary.Classes;
using ElectronicDiary.Pages;
using Excel = Microsoft.Office.Interop.Excel;
using System.IO;

namespace ElectronicDiary.Pages
{
    /// <summary>
    /// Логика взаимодействия для PageEvaluation.xaml
    /// </summary>
    public partial class PageEvaluation : Page
    {
        public PageEvaluation()
        {
            InitializeComponent();
            DtgEva.ItemsSource = ElectronicDiaryEntities.GetContext().Evaluation.ToList();
        }

        private void SearchStudentEva_TextChanged(object sender, TextChangedEventArgs e)
        {
            if (DtgEva.ItemsSource != null)
            {
                DtgEva.ItemsSource = ElectronicDiaryEntities.GetContext().Evaluation.Where(x => x.Student.FIO.ToLower().Contains(SearchStudentEva.Text.ToLower())).ToList();
            }
            if (SearchStudentEva.Text.Count() == 0) DtgEva.ItemsSource = ElectronicDiaryEntities.GetContext().Evaluation.ToList();
        }

        private void MenuSortClear_Click(object sender, RoutedEventArgs e)
        {
            DtgEva.ItemsSource = ElectronicDiaryEntities.GetContext().Evaluation.ToList();
        }

        private void MenuDelMark_Click(object sender, RoutedEventArgs e)
        {
            var MarkForRemoving = DtgEva.SelectedItems.Cast<Evaluation>().ToList();
            if (MessageBox.Show($"Вы точно хотите удалить следующие {MarkForRemoving.Count()} записи?", "Внимание", MessageBoxButton.YesNo, MessageBoxImage.Question) == MessageBoxResult.Yes)
            {
                try
                {
                    ElectronicDiaryEntities.GetContext().Evaluation.RemoveRange(MarkForRemoving);
                    ElectronicDiaryEntities.GetContext().SaveChanges();
                    MessageBox.Show("Оценка удалена!");
                    DtgEva.ItemsSource = ElectronicDiaryEntities.GetContext().Evaluation.ToList();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message.ToString());
                }
            }
        }

        private void MenuSortMarkUp_Click(object sender, RoutedEventArgs e)
        {
            DtgEva.ItemsSource = ElectronicDiaryEntities.GetContext().Marks.OrderBy(x => x.Mark).ToList();
        }

        private void MenuSortMarkDown_Click(object sender, RoutedEventArgs e)
        {
            DtgEva.ItemsSource = ElectronicDiaryEntities.GetContext().Marks.OrderByDescending(x => x.Mark).ToList();
        }

        private void MenuAddMark_Click(object sender, RoutedEventArgs e)
        {
            Classes.ClassFrame.frmObj.Navigate(new PageAddMark(null));
        }

        private void MenuEditMark_Click(object sender, RoutedEventArgs e)
        {
            Classes.ClassFrame.frmObj.Navigate(new PageAddMark((Evaluation)DtgEva.SelectedItem));
        }

        private void Filter5_Click(object sender, RoutedEventArgs e)
        {
            DtgEva.ItemsSource = ElectronicDiaryEntities.GetContext().Marks.Where(x => x.Mark >= 5).ToList();
        }

        private void SearchSubjectEva_TextChanged(object sender, TextChangedEventArgs e)
        {
            if (DtgEva.ItemsSource != null)
            {
                DtgEva.ItemsSource = ElectronicDiaryEntities.GetContext().Evaluation.Where(x => x.Subject.TitleSubject.ToLower().Contains(SearchSubjectEva.Text.ToLower())).ToList();
            }
            if (SearchSubjectEva.Text.Count() == 0) DtgEva.ItemsSource = ElectronicDiaryEntities.GetContext().Evaluation.ToList();
        }

        private void Filter4_Click(object sender, RoutedEventArgs e)
        {
            DtgEva.ItemsSource = ElectronicDiaryEntities.GetContext().Marks.Where(x => x.Mark >= 4 && x.Mark <= 4).ToList();
        }

        private void Filter3_Click(object sender, RoutedEventArgs e)
        {
            DtgEva.ItemsSource = ElectronicDiaryEntities.GetContext().Marks.Where(x => x.Mark >= 3 && x.Mark <= 3).ToList();
        }

        private void Filter2_Click(object sender, RoutedEventArgs e)
        {
            DtgEva.ItemsSource = ElectronicDiaryEntities.GetContext().Marks.Where(x => x.Mark >= 2 && x.Mark <= 2).ToList();
        }

        private void Excel_Click(object sender, RoutedEventArgs e)
        {

            Excel.Application excelApp = new Excel.Application();
            Excel.Workbook wb = excelApp.Workbooks.Open($"{Directory.GetCurrentDirectory()}\\ОтчётОбУспеваемости.xlsx");
            Excel.Worksheet ws = (Excel.Worksheet)wb.Worksheets[1];

            ws.Cells[2, 7] = DateTime.Now.ToString();

            int indexRows = 6;

            ws.Cells[2][indexRows] = "ФИО студента";
            ws.Cells[3][indexRows] = "Предмет";
            ws.Cells[4][indexRows] = "Оценка";
            ws.Cells[5][indexRows] = "ФИО учителя";

            var printItems = DtgEva.Items;
            foreach (Evaluation item in printItems)
            {
                ws.Cells[2][indexRows + 1] = item.Student.FIO;
                ws.Cells[5][indexRows + 1] = item.Teacher.FIO;
                ws.Cells[3][indexRows + 1] = item.Subject.TitleSubject;
                //ws.Cells[4][indexRows + 1] = item.Marks.Mark;

                indexRows++;
            }
            ws.Columns.AutoFit();
            ws.Cells[indexRows + 3, 7] = "Подпись директора";
            ws.Cells[indexRows + 4, 7] = "Кулаков А.И";
            excelApp.Visible = true;

        }
    }
}

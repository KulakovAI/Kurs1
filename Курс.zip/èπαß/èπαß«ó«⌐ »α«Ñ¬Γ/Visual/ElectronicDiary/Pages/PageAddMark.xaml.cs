﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using ElectronicDiary.Classes;

namespace ElectronicDiary.Pages
{
    /// <summary>
    /// Логика взаимодействия для PageAddMark.xaml
    /// </summary>
    public partial class PageAddMark : Page
    {
        private Evaluation _currentMark = new Evaluation();
        public PageAddMark(Evaluation selectedMark)
        {
            InitializeComponent();
            if (selectedMark != null)
            {
                _currentMark = selectedMark;
                TitleCitizen.Text = "Изменение оценки";
                BtnAddMark.Content = "Изменить";
                CMBfioSt.IsEnabled = false;
                CMBfioT.IsEnabled = false;
                CMBsubject.IsEnabled = false;
            }
            DataContext = _currentMark;

            CMBMark.ItemsSource = ElectronicDiaryEntities.GetContext().Marks.ToList();
            CMBMark.SelectedValuePath = "idMark";
            CMBMark.DisplayMemberPath = "Mark";

            CMBfioSt.ItemsSource = ElectronicDiaryEntities.GetContext().Student.ToList();
            CMBfioSt.SelectedValuePath = "idStudent";
            CMBfioSt.DisplayMemberPath = "FIO";

            CMBfioT.ItemsSource = ElectronicDiaryEntities.GetContext().Teacher.ToList();
            CMBfioT.SelectedValuePath = "idTeacher";
            CMBfioT.DisplayMemberPath = "FIO";

            CMBsubject.ItemsSource = ElectronicDiaryEntities.GetContext().Subject.ToList();
            CMBsubject.SelectedValuePath = "idSubject";
            CMBsubject.DisplayMemberPath = "TitleSubject";
        }

        private void BtnAddMark_Click(object sender, RoutedEventArgs e)
        {
            StringBuilder error = new StringBuilder();
            if (string.IsNullOrWhiteSpace(Convert.ToString(_currentMark.idStudent))) error.AppendLine("Укажите ФИО студента");
            if (string.IsNullOrWhiteSpace(Convert.ToString(_currentMark.idTeacher))) error.AppendLine("Укажите ФИО учителя");
            if (string.IsNullOrWhiteSpace(Convert.ToString(_currentMark.idSubject))) error.AppendLine("Укажите предмет");
            if (string.IsNullOrWhiteSpace(Convert.ToString(_currentMark.idMark))) error.AppendLine("Укажите оценку");
            if (error.Length > 0)
            {
                MessageBox.Show(error.ToString());
                return;
            }
            if (_currentMark.idStudent == 0)
            {
                ElectronicDiaryEntities.GetContext().Evaluation.Add(_currentMark);
                try
                {
                    ElectronicDiaryEntities.GetContext().SaveChanges();
                    Classes.ClassFrame.frmObj.Navigate(new PageEvaluation());
                    MessageBox.Show("Оценка успешно выставлена!");
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message.ToString());
                }
            }
            else
            {
                try
                {
                    ElectronicDiaryEntities.GetContext().SaveChanges();
                    Classes.ClassFrame.frmObj.Navigate(new PageEvaluation());
                    MessageBox.Show("Оценка успешно изменена!");
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message.ToString());
                }
            }
        }

        private void BtnCancelMark_Click(object sender, RoutedEventArgs e)
        {
            Classes.ClassFrame.frmObj.Navigate(new PageEvaluation());
        }
    }
}
